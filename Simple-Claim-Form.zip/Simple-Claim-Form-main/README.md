# Simple-Claim-Form
Android App for creating a simple dynamic form with MVVM architecture

Androidx Components used : Navigation component, Dagger-Hilt, ViewModel, Corounites, LiveData

Example is using a raw json file to generate the Simple Claim Form.

Reference url : http://files.mobisy.com/downloads/Claims_Add.mp4
