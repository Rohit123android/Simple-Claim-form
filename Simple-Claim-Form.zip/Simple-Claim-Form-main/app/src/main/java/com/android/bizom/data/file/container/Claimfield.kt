package com.android.bizom.data.file.container

data class Claimfield(val type: String, val label: String, val required: Int, var input: String)
