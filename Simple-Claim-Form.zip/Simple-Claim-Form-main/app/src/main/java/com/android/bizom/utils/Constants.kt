package com.android.bizom.utils

object Constants {

    const val DROP_DOWN = "DropDown"
    const val SINGLE_LINE_TEXT_ALL_CAPS = "SingleLineTextAllCaps"


}