package com.android.bizom.data.file.container

data class Claim(val Claimtype: Claimtype, val Claimtypedetail: List<Claimtypedetail>)
