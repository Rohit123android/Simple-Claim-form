package com.android.bizom.data.file.container

data class Claimtype(val name: String, val id: String)
