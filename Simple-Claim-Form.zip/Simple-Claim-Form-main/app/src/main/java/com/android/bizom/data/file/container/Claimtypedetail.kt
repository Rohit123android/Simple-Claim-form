package com.android.bizom.data.file.container

data class Claimtypedetail(
    val id : String,
    val Claimfield: Claimfield
    )
