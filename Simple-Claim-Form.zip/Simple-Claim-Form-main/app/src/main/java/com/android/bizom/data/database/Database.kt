package com.android.bizom.data.database

class Database {
}